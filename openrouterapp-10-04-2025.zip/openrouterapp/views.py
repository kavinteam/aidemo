import requests
import json
from django.shortcuts import render

def LoginPage(request):
    reply = ""

    if request.method == "POST":
        user_question = request.POST.get("question", "")

        payload = {
            "model": "openai/gpt-4o",
            "messages": [
                {
                    "role": "user",
                    "content": user_question
                }
            ],
            "max_tokens": 512  # <- Limit the response size to stay within free tier
        }

        response = requests.post(
            url="https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": "Bearer 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",
                "HTTP-Referer": "https://yourdomain.com",
                "X-Title": "My Django App",
                "Content-Type": "application/json"
            },
            data=json.dumps(payload)
        )

        try:
            result = response.json()
            if "choices" in result:
                reply = result["choices"][0]["message"]["content"]
            elif "error" in result:
                reply = f"OpenRouter Error: {result['error']['message']}"
            else:
                reply = f"Unexpected response: <pre>{json.dumps(result, indent=2)}</pre>"
        except Exception as e:
            reply = f"Error parsing OpenRouter response: {str(e)}<br><pre>{response.text}</pre>"

    return render(request, 'test.html', {'reply': reply})
